# SENPAI.AC

Futuristic anime/cyber personal profile website.

## Included
- index.html — main page; JavaScript is included inside index.html.
- style.css — complete styling.
- README.md — documentation.

## Features
- 🎮 Gaming-style loading screen
- 🌌 Futuristic anime/cyber UI
- 👤 Profile section
- 🔗 Instagram, GitHub, YouTube, Discord cards
- 📱 Mobile responsive
- ⏰ Live system clock
- 🚀 GitHub Pages compatible
- 🖼️ Supplied anime background embedded in style.css

## GitHub Pages
Upload all three files to the repository root. Make sure the homepage is exactly `index.html` (lowercase). Then use Settings → Pages → Deploy from a branch → `main` → `/(root)`.

## Social links
In `index.html`, replace the four `href="#"` values with your real Instagram, GitHub, YouTube and Discord URLs.
