const boot = document.getElementById("boot-screen");
const site = document.getElementById("site");
const bar = document.getElementById("progress-bar");
const percent = document.getElementById("boot-percent");
const status = document.getElementById("boot-status");
const enter = document.getElementById("enter-btn");

let p = 0;
const timer = setInterval(() => {
  p += Math.floor(Math.random() * 9) + 3;
  if (p >= 100) {
    p = 100;
    clearInterval(timer);
    status.textContent = "SYSTEM READY. AWAITING USER...";
    enter.style.display = "inline-block";
  }
  bar.style.width = p + "%";
  percent.textContent = p + "%";
}, 110);

function enterSystem() {
  boot.classList.add("off");
  site.classList.remove("hidden");
  setTimeout(() => boot.remove(), 900);
}
enter.addEventListener("click", enterSystem);

document.getElementById("menu-btn").addEventListener("click", () => {
  document.getElementById("nav-links").classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("nav-links").classList.remove("open");
}));

function updateClock() {
  const now = new Date();
  document.getElementById("clock").textContent = now.toLocaleTimeString("en-GB");
}
updateClock();
setInterval(updateClock, 1000);
