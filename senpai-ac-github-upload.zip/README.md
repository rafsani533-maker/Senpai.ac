# SENPAI.AC

A futuristic anime/gaming-style personal profile website.

## Upload to GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**.
6. Save and wait for GitHub Pages to publish your site.

## Customize

Open `index.html` and replace:
- `YOUR PHOTO` / `YOUR PROFILE IMAGE`
- `@your_username`
- the `href="#"` social links
- profile text and project details

Your main website file must remain named exactly `index.html`.
